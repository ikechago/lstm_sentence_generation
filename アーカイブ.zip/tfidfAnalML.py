#############################################################
#                 Author: Incheon Paik                      #
#                 March 1, 2019                             #
#############################################################
import math
import collections
import numpy as np
import nltk
import random
import sys
from random import seed
from random import sample
from pprint import pprint
from collections import Counter
from collections import defaultdict
#import cal_tfidf

##### Function getContentsFromFiles  #####
def getContentsFromFiles(filep, filen):
## The file consists of sentences filtered by NL processor. A line is a sentence.
  with open(filep, encoding="utf-8_sig") as fp:
    contentsp = fp.readlines()
    #contentsp.rstrip()
  #with open(filen) as fn:
  with open(filen, encoding="utf-8_sig") as fn:
    contentsn = fn.readlines()
    #contentsn.rstrip()
  return contentsp, contentsn
##### Enf of Function getContentsFromFiles  #####

from nltk import sent_tokenize
from nltk.corpus import stopwords
#nltk.download('stopwords')
#nltk.download('punkt')
#nltk.download('averaged_perceptron_tagger')
##### Function getContentsFromFiles  #####
def getProcessedContentsFromFiles(filep, filen):
## The files consist of lines, and a line may consists of several sentences. 
## It identifies sentence by NLTK. It provides the function that can select some POSs for better proformance. 
  stopWords = set(stopwords.words('english'))
  with open(filep, encoding="utf-8_sig") as fp:
    contentsp = fp.readlines()
    contentStringp = "".join(contentsp)
    contentStringp.rstrip()
    sentencesp = sent_tokenize(contentStringp)
    sep_sentencesp = []
    for sent1 in sentencesp:
      tagged_token = word_tokenize(sent1)
      tagged_words = nltk.pos_tag(tagged_token)
      #sep_sentence = " ".join(w for (w,t) in tagged_words)
      sep_sentence = " ".join(w for (w,t) in tagged_words if w not in stopWords if t == 'NN' or t == 'NNP' or t == 'PP' or t == 'PRP' or t == 'VBD' or t == 'VBG' or t == 'VBP' or t == 'BVN' or t == 'JJ' or t == 'JJS' or t == 'JJR')
      #sep_sentence = " ".join(w for (w,t) in tagged_words if w not in stopWords if t == 'NN' or t == 'PP' or t == 'PRP' or t == 'VBD' or t == 'JJ')
      sep_sentencesp.append(sep_sentence)

  with open(filen, encoding="utf-8_sig") as fn:
    contentsn = fn.readlines()
    contentStringn = "".join(contentsn)
    contentStringn.rstrip()
    sentencesn = sent_tokenize(contentStringn)
    sep_sentencesn = []
    for sent1 in sentencesn:
      tagged_token = word_tokenize(sent1)
      tagged_words = nltk.pos_tag(tagged_token)
      #sep_sentence = " ".join(w for (w,t) in tagged_words)
      sep_sentence = " ".join(w for (w,t) in tagged_words if w not in stopWords if t == 'NN' or t == 'NNP' or t == 'PP' or t == 'PRP' or t == 'VBD' or t == 'VBG' or t == 'VBP' or t == 'BVN' or t == 'JJ' or t == 'JJS' or t == 'JJR')
      #sep_sentence = " ".join(w for (w,t) in tagged_words if w not in stopWords if t == 'NN' or t == 'PP' or t == 'PRP' or t == 'VBD' or t == 'JJ')
      sep_sentencesn.append(sep_sentence)

  return contentsp, contentsn, sentencesp, sentencesn, sep_sentencesp, sep_sentencesn
  ## Return Value Description of the function "getProcessedContentsFromFiles(inFile1, inFile2)
  #contentsp, contentsn, sentencesp, sentencesn, sep_sentencesp, sep_sentencesn 
  # 1. contentsp, contentsn -- Original contents (list). A line may contain several setences. The list contains several lines as elements. 
  # 2. sentencesp, sentencesn -- Original data has been splitted into each sentence. But each word in the sentence has not been seperated. A list contains sentences with unseparated words.
  # 3. sep_sentencesp, sep_sentencesn -- Separated words in a sentence. A list contains sentences with separated words.
  # Invocation Example: contentsp, contentsn, sentencesp, sentencesn, sep_sentencesp, sep_sentencesn = getProcessedContentsFromFiles(inFileNames[0], inFileNames[1])
##### Enf of Function getProcessedContentsFromFiles  #####

##### Function getProcessedContentsByLineFromFiles  #####
def getProcessedContentsByLineFromFiles(filep, filen):
## The files consist of lines, and a line means a document.  
## It identifies sentence by NLTK. It provides the function that can select some POSs for better proformance. 
  global noPdata
  global noNdata
  global noTotaldata
## The files consist of lines, and the lines build an entire document.
  stopWords = set(stopwords.words('english'))
  #with open(filep) as fp:
  with open(filep, encoding="utf-8_sig") as fp:
    linesp = fp.readlines()
    lineContentsp = []
    for line in linesp:
      contentStringp = "".join(line)
      contentStringp.rstrip()
      sentencesp = sent_tokenize(contentStringp)
      sep_sentencesp = []
      for sent1 in sentencesp:
        tagged_token = word_tokenize(sent1)
        tagged_words = nltk.pos_tag(tagged_token)
        sep_sentence = " ".join(w for (w,t) in tagged_words)
        #sep_sentence = " ".join(w for (w,t) in tagged_words if w not in stopWords if t == 'NN' or t == 'NNP' or t == 'PP' or t == 'PRP' or t == 'VBD' or t == 'VBG' or t == 'VBP' or t == 'BVN' or t == 'JJ' or t == 'JJS' or t == 'JJR')
        #sep_sentence = " ".join(w for (w,t) in tagged_words if w not in stopWords if t == 'NN' or t == 'PP' or t == 'PRP' or t == 'VBD' or t == 'JJ')
        sep_sentencesp.append(sep_sentence)
      lineContentsp.append(" ".join(sep_sentencesp))

  #with open(filen) as fn:
  with open(filen, encoding="utf-8_sig") as fn:
    linesn = fn.readlines()
    lineContentsn = []
    for line in linesn:
      contentStringn = "".join(line)
      contentStringn.rstrip()
      sentencesn = sent_tokenize(contentStringn)
      sep_sentencesn = []
      for sent1 in sentencesn:
        tagged_token = word_tokenize(sent1)
        tagged_words = nltk.pos_tag(tagged_token)
        sep_sentence = " ".join(w for (w,t) in tagged_words)
        #sep_sentence = " ".join(w for (w,t) in tagged_words if w not in stopWords if t == 'NN' or t == 'NNP' or t == 'PP' or t == 'PRP' or t == 'VBD' or t == 'VBG' or t == 'VBP' or t == 'BVN' or t == 'JJ' or t == 'JJS' or t == 'JJR')
        #sep_sentence = " ".join(w for (w,t) in tagged_words if w not in stopWords if t == 'NN' or t == 'PP' or t == 'PRP' or t == 'VBD' or t == 'JJ')
        sep_sentencesn.append(sep_sentence)
      lineContentsn.append(" ".join(sep_sentencesn))

  input_documents = lineContentsp + lineContentsn
  noPdata = len(lineContentsp)
  noNdata = len(lineContentsn)
  noTotaldata = len(input_documents)
  print('Size of Positive line document data = ', noPdata)
  print('Size of Negative line document data = ', noNdata)
  print('Size of Total line document data = ', noTotaldata)

  return input_documents, lineContentsp, lineContentsn
##### Enf of Function getProcessedContentsByLineFromFiles  #####


##### Function : Building Input Data #####
def buildingInputData(conth, contm):
  global noPdata
  global noNdata
  global noTotaldata
  global linesPerDoc
  # Each Data Set has 150,000 lines.
  # First, 1 Doc - 100 lines, 1500 documents creation
  pData = []
  nData = []
  for idx in range(int(len(conth)/linesPerDoc)):
    templ = conth[(idx)*linesPerDoc:(idx+1)*linesPerDoc]
    temps = ""
    for i,s1 in enumerate(templ):
      temps = temps + str(s1).strip() + " "
    temps += "\n"
    pData.append(temps)
  for idx in range(int(len(contm)/linesPerDoc)):
    templ = contm[(idx)*linesPerDoc:(idx+1)*linesPerDoc]
    temps = ""
    for i,s1 in enumerate(templ):
      temps = temps + str(s1).strip() + " "
    temps += "\n"
    nData.append(temps)
  input_documents = pData + nData
  noPdata = len(pData)
  noNdata = len(nData)
  noTotaldata = len(input_documents)

  print('No. of Human Documents = ', noPdata)
  print('No. of Machine Documents = ', noNdata)
  print('No. of Total Document Data = ', noTotaldata)

  return input_documents
##### End of Function : Make Input Data #####

##### Function for Getting N-Gram #####
from nltk.tokenize import word_tokenize
from nltk.util import ngrams

def get_ngrams(text, n ):
    n_grams = ngrams(word_tokenize(text), n)
    return [ " ".join(grams) for grams in n_grams]

##### End of Function : Get N-Gram #####

##### Function for buildingDictionaries #####
def buildDictionaries():
  ## Build words and counter
  global input_documents
  global nGram 
  global no_nGram 
  
  #################################################
  ## When nGram == 1
  if nGram <= 1:
    words = "".join(input_documents).split();  
    count = collections.Counter(words).most_common()
    #print ('count = ', count)
  ## When nGram > 1
  else: 
    words = get_ngrams("".join(input_documents), nGram )
    count_all = collections.Counter(words).most_common()
    count = count_all[:no_nGram]

  ## Build dictionaries --> rdic, dic, docDataDic
  #rdic --- idx -> word
  #dic --- word -> id
  #docDataDic --- document -> id

  # Word Dictionaries --> rdic, dic
  rdic = [i[0] for i in count] #reverse dic, idx -> word
  print('Size of Dictionary = ', len(rdic))
  dic = {w: i for i, w in enumerate(rdic)} #dic, word -> id
  # Document Dictionary --> docDataDic
  for i, doc in enumerate(input_documents):
    v = docDataDic.get(doc)
    if v is None:
      docDataDic[doc] = i
    else:
      print('Fatal Error in Data! You have the same contents in your documents. Remove the data record below and try again. Terminating.. ')
      print('The record index = ', i)
      print('The content of the record = \n', doc)
      sys.exit()
  #print('docDic = ', docDataDic)

  return rdic, dic, docDataDic
##### End of Function for Building Dictionaries

##### Function  of calculating TFIDF
def cal_tfidf():
  global dic
  global rdic
  global docDataDic
  global nGram 
  # Calculating TFIDF
  N = len(docDataDic.keys())

  docTFtable = defaultdict(Counter);
  DFtable = Counter();
  docTFIDFtable = defaultdict(Counter);

  ## Calculating TF
  print("Calculating TF and DF if it is Unigram...")
  for document in docDataDic.keys():
    ## When nGram == 1
    if nGram <= 1:
      words = document.split();
      thisDoc = docDataDic.get(document)
    else: 
      words_all = get_ngrams(document, nGram)
      words = [w for w in words_all if w in rdic]
      thisDoc = docDataDic.get(document)
    ## Calculating TF
    #print("Calculating TF...")
    for word in words:
      docTFtable[thisDoc][word] += 1;

    ## Calculating DF
    #print("Calculating DF...")
    ## When nGram == 1
    if nGram <= 1:
      for kw in docTFtable[thisDoc].keys():   # If kw has been fixed and defined.
        DFtable[kw] += 1;

  ## Calculating DF for N-Gram
  print("Calculating DF for N-Gram...")
  if nGram > 1:
    idxt = 0
    #print("Calculating DF...")
    for ngword in rdic:
      idxt = idxt + 1
      if idxt % 2000 == 0:
        print('ngword count = ', idxt)
        sys.stdout.flush()
        #print('ngword = ', ngword)
      for document in docDataDic.keys():
        ngwords = ngword.split()
        if all(s in document for s in ngwords):
          DFtable[ngword] += 1;
  else:
    print('DF was already calculated as Unigram, next TFIDF calculation..')
  print("End of Calculate TF and DF, Next TF-IDF...")
  ## Calculating TF-IDF
  for document in docDataDic.keys():
    thisDoc = docDataDic.get(document)
    for kw in docTFtable[thisDoc].keys():
      docTFIDFtable[thisDoc][kw] = docTFtable[thisDoc][kw] * math.log(N/DFtable[kw]);
    #print('After TFIDF cal:  doc = ', thisDoc, document)
    #print(docTFIDFtable[thisDoc])
  return docTFIDFtable 
##### End of Function - calculating TFIDF

### Function getidfTFIDF value only
def getidxTFIDF():
  global dic
  global docDataDic
  global docTFIDFdata
  global noPdata
  global docSize
  global vocSize
  global classDoc 

  docSize = len(docDataDic.keys());
  vocSize = len(dic)
  tfIDFval = [[ 0.0 for x in range(vocSize)] for y in range(docSize)]
  classDoc = [0 for i in range(noTotaldata)]

  docindex = 0
  for document in docDataDic.keys():
    thisDoc = docDataDic.get(document)
    #dataListWordVal = [(x, docTFIDFdata[thisDoc].get(x)) for x in docTFIDFdata[thisDoc].keys()]
    #dataListWordVal = docTFIDFdata[thisDoc].most_common()
    for x in docTFIDFdata[thisDoc].keys():
      if dic.get(x) is None:
        continue
      tfIDFval[docindex][dic.get(x)] = docTFIDFdata[thisDoc].get(x)   
    if (docindex < noPdata): 
      classDoc[docindex] = 1
    else:
      classDoc[docindex] = -1
    docindex = docindex + 1
  return tfIDFval
### End of getidxTFIDF

##### Function : Create Train and Test Data #####
def createTrainTestData(tfidfdata, rate):
#Using tfidfdata, classDoc, and rate
  global noPdata
  global noNdata
  global noTotaldata
  global classDoc
  global vocSize
  global docSize
  global noTrain
  global noTest
  global seedVal

  tfidfWithClass = [[ 0.0 for x in range(vocSize+1)] for y in range(docSize)]

  noTrain = int (noTotaldata * (rate / 100))
  noTest = noTotaldata - noTrain

  for i in range(noTotaldata):
    tfidfWithClass[i] =  tfidfdata[i]
    tfidfWithClass[i].insert(0,int(classDoc[i])) 

  #print('tfidfWithClass = ', tfidfWithClass)
  # For Training Data
  seed(seedVal)
  train_idx_val = sample(list(enumerate(tfidfWithClass)), noTrain)    
  total_indexes = [i for i in range(docSize)]
  train_indexes = []
  test_indexes = []
  forTestDataSet = []
  trainData = []
  testData = []
  for idx, val in train_idx_val:
    train_indexes.append(idx)
    trainData.append(val)
  #print('total_indexes = ', total_indexes)
  #print('train_indexes = ', train_indexes)

  # For Testing Data
  #seed(seedVal)
  #test_indexes = total_indexes - train_indexes
  test_indexes = [item for item in total_indexes if item not in train_indexes]
  #print('test_indexes = ', test_indexes)
  forTestDataSet = [tfidfWithClass[i] for i in test_indexes]
  testData = sample(forTestDataSet, noTest)    

  #print('Train Data Set = ', trainData)
  #print('Test Data Set = ', testData)
  print('Number of Train Data = ', noTrain)
  print('Number of Test Data = ', noTest)

  return trainData, testData
##### End of Function: Create Train Test Data 

import re
import numpy as np
import nltk
from nltk.stem.porter import *
from nltk.corpus import stopwords
import pandas as pd
import seaborn as sns; sns.set(font_scale=1.2)

#import matplotlib
#from matplotlib import pyplot as plt
#data= np.random.permutation(data)

from sklearn.svm import SVC
from sklearn import preprocessing
from sklearn import utils
from sklearn.metrics import accuracy_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.datasets import make_classification

##### Function: Output Result
def analysis(tfidfval, width, ml_algorithm):
  global rdic
  global input_documents
  global docDataDic
  global classDoc
  global noTrain
  global noTest
  #global ml_algorithm

  print('Modeling and Analysis...')
  docSize = len(docDataDic.keys())

  # create train and test data by random sample 
  train, test = createTrainTestData(tfidfval, 60) 

  X_train = [ x[1:width+1] for x in train ]
  X_test = [ x[1:width+1] for x in test ]
  y_train = [ y[0] for y in train ]
  y_test = [ y[0] for y in test ]

  #from sklearn.model_selection import train_test_split
  #X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=0) 

  if (ml_algorithm == "SVM"):
    ## Create Model by SVM  
    print("Modeling by SVM")
    model = SVC(kernel='linear', random_state=None)
    model.fit(X_train, y_train)
  elif (ml_algorithm == "RF"):
    ## Create Model by RM  
    print("Modeling by RF")
    model = RandomForestClassifier(n_estimators=100, max_depth=3, random_state=0)
    model.fit(X_train, y_train)
    print('Feature Importances..')
    print(model.feature_importances_)
  
    implist, importanceValue = getImportance(model.feature_importances_)  #Getting importance value list
    ## Output Important Words(N-Gram)-Value pairs
    printImportantWords(implist, importanceValue)
  else: 
    print("This doesn't support this ML algorithm!")

  # Testing...
  preout = model.predict(X_test)
  print('Using test data set, Accuracy = ', accuracy_score(y_test, preout))
##### End of Function: Analysis by Machine Learning 

####### Start of Function readImportance #######
def getImportance(featureImportances):  #Reading data and return importance value list
  idxSort = np.full(100,0,dtype=int)
  valueSort = np.full(100,0.,dtype=float)
  x = featureImportances
  for i in range(len(x)):
    idxSort[i] = np.argsort(x)[::-1][i]
    valueSort[i] = np.sort(x)[::-1][i]
  idxlist = idxSort.tolist()
  valuelist = valueSort.tolist()
  return idxlist, valuelist
##### End of Function: readImportance

####### Start of Function printImportantWords #######
def printImportantWords(implist, importanceValue):  # Receiving importance value list, and return sorted important words
  global dataColWidth
  global impResultOutFiles
  global rdic

  wordsSorted = []
  with open(impResultOutFiles[0], 'w') as outfdic:
    print('N-Gram Word Dictionary = ', rdic[:dataColWidth+1], file=outfdic)
  outfdic.close()

  for idx in implist:
    wordsSorted.append(rdic[idx])
  dataForPrint = {w:importanceValue[i] for i, w in enumerate(wordsSorted)}

  with open(impResultOutFiles[1], 'w') as outf:
    print('N-Gram Word: ImportanceValue = ', dataForPrint, file=outf)
  outf.close()

  print("Result has been saved at ({}) for the word dictionary, ({}) for word-imporantce value.".format(impResultOutFiles[0], impResultOutFiles[1]))

##### End of Function: printImportantWords #####


####### Start of Main #######
## Global Variables
noPdata = 0            # number of Human data (documents)
noNdata = 0            # number of Machine data (documents)
noTotaldata = 0        # number of Total data (documents)
vocSize = 0            # size of vocabulary
docSize = 0            # size of documents
noTrain = 0            # number of train data
noTest = 0             # number of train data
rdic = []              # idx -> word
dic = {}               # word -> id
docDataDic = {}        # document -> id
input_documents = []   # contents of whole input documents
classDoc = []          # class information of all documents
docTFIDFdata = {}      # TFIDF data of all documents

## Parameters
#inFileNames = ['pp1.txt', 'nn1.txt']  # Input File Names for Human and Machine
inFileNames = ['sports.txt', 'tech.txt']  # Input File Names for Human and Machine
#inFileNames = ['Human.txt', 'Machine.txt']  # Input File Names for Human and Machine
outFilePrefix = 'hm'   # Prefix data of the output file names for training and test CSV data
impResultOutFiles = ['wordDic-Uni.txt', 'impWordValResult-Uni.txt']
linesPerDoc = 100      # Number of lines per a document
trainRate = 60         # Portion of Training Data (Rate/100)
seedVal = 1            # seed value for random sampling
dataColWidth = 100     # Width (number of column - features) for training and test data 
nGram = 1              # value of N-Gram
no_nGram = 20000       # number of N-Gram words to be used 

## Some Options
#ml_algorithm = "RF"    # kind of ML algorithm - "SVM" or "RF"
ml_algorithm = "SVM"    # kind of ML algorithm - "SVM" or "RF"
#inputType = "SENTENCE"  # 3 Types: LINE, ANY, SENTENCE --> LINE(A line is a document), ANY(A line may contain several lines.. Any structure..), SENTENCE(A line is a sentence that processed by NL Processsor.)
inputType = "LINE"  # 3 Types: LINE, ANY, SENTENCE --> LINE(A line is a document), ANY(A line may contain several lines.. Any structure..), SENTENCE(A line is a sentence that processed by NL Processsor.)

## Read Input
if inputType is "LINE":
  input_documents, _, _ =  getProcessedContentsByLineFromFiles(inFileNames[0], inFileNames[1])
elif inputType is "SENTENCE":
  contentsp, contentsn = getContentsFromFiles(inFileNames[0], inFileNames[1])
  #contentsp, contentsn, _, _, _, _ = getProcessedContentsFromFiles(inFileNames[0], inFileNames[1])
else:   #ANY
  _, _, _, _, contentsp, contentsn = getProcessedContentsFromFiles(inFileNames[0], inFileNames[1])
  #contentsp, contentsn, sentencesp, sentencesn, sep_sentencesp, sep_sentencesn = getProcessedContentsFromFiles(inFileNames[0], inFileNames[1])

## Building Input Data
if inputType is not "LINE":
  input_documents = buildingInputData(contentsp, contentsn)

## Build Dictionaries
rdic, dic, docDataDic = buildDictionaries()

## Calculate TFIDF ###
docTFIDFdata = cal_tfidf()

## Get Index Format For CSV File  ###
tfidfval = getidxTFIDF()

## Analysis using Machine Learning  ###
analysis(tfidfval, dataColWidth, ml_algorithm)

##### End of Main #####

